#ifndef FOCALPOINTFocalPointBoundaryPixelTracker_H
#define FOCALPOINTFocalPointBoundaryPixelTracker_H


/**
@author m
*/
#include <map>
#include <CompuCell3D/Field3D/Point3D.h>
#include <CompuCell3D/dllDeclarationSpecifier.h>

namespace CompuCell3D {

   
   
   //common surface area is expressed in unitsa of elementary surfaces not actual physical units. If necessary it may 
   //need to be transformed to physical units by multiplying it by surface latticemultiplicative factor 
   class DECLSPECIFIER FocalPointBoundaryPixelTrackerData{
      public:
      FocalPointBoundaryPixelTrackerData():cadLevel(0.0),inContact(false){
				// pixel=Point3D();
			}
         // FocalPointBoundaryPixelTrackerData(Point3D _pixel)
         // :pixel(_pixel)
          
          // {}
         
         ///have to define < operator if using a class in the set and no < operator is defined for this class
         // bool operator<(const FocalPointBoundaryPixelTrackerData & _rhs) const{
            // return pixel.x < _rhs.pixel.x || (!(_rhs.pixel.x < pixel.x)&& pixel.y < _rhs.pixel.y)
					// ||(!(_rhs.pixel.x < pixel.x)&& !(_rhs.pixel.y <pixel.y )&& pixel.z < _rhs.pixel.z);
         // }
         
         // bool operator==(const FocalPointBoundaryPixelTrackerData & _rhs)const{
            // return pixel==_rhs.pixel;
         // }
         
         ///members
         // Point3D pixel;
         double cadLevel;
			bool inContact;

			

                  
   };

   
   
   class DECLSPECIFIER FocalPointBoundaryPixelTracker{
      public:
         FocalPointBoundaryPixelTracker(){};
         
         ~FocalPointBoundaryPixelTracker(){};
         std::map<Point3D, FocalPointBoundaryPixelTrackerData> pixelCadMap; //stores cadherin levels for boundary pixels
			double totalCadLevel;
			double reservoir;
			
         
   };
};
#endif
