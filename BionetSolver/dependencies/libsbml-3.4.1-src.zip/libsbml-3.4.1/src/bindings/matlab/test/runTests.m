%% Description       : Script for running MATLAB tests
%% Original author(s): Michael Hucka <mhucka@caltech.edu>
%% Organization      : California Institute of Technology
%% $Id: runTests.m 8704 2009-01-04 02:26:05Z mhucka $
%% $HeadURL: https://sbml.svn.sourceforge.net/svnroot/sbml/trunk/libsbml/src/bindings/matlab/test/runTests.m $

addpath('..')
addpath('../../..')
testBinding
exit
